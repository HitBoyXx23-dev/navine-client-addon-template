package nv.navineclient.addon;

/**
 * Example addon entrypoint.
 *
 * Replace this with Navine Client's actual addon interface/base class.
 * If your client uses a specific interface (e.g., NavineAddon), implement it here.
 */
public class ExampleAddon {

    public ExampleAddon() {
        // Addon init (placeholder)
    }
}
