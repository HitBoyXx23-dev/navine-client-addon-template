package nv.navineclient.addon;

import nv.navineclient.MeteorAddon;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExampleAddon extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("ExampleAddon");

    @Override
    public void onInitialize() {
        LOG.info("Example Addon for Navine Client initialized!");
    }

    @Override
    public void onRegisterCategories() {
        // Register your module categories here
    }

    @Override
    public String getPackage() {
        return "nv.navineclient.addon";
    }
}
